# DisableCombatLog v1.0

Performance improving add-on that disables the combat log. This add-on is simply doing the equivalent of this when you login with a character:

`/script TextLogSetEnabled ("Combat", false)`

If you wish to enable to the combat log again, either disable this add-on or put this command in chat:

`/script TextLogSetEnabled ("Combat", true)`
